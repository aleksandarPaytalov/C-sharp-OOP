﻿using FoodShortage.Core;

Engine engine = new Engine();
engine.Run();