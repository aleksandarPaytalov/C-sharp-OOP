﻿namespace FoodShortage.Models.Interfaces
{
    public interface IBirthdate
    {
        string Birthday { get; }
    }
}
