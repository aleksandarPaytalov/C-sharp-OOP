﻿namespace FoodShortage.Models.Interfaces
{
    public interface IAged
    {
        int Age { get; }
    }
}
