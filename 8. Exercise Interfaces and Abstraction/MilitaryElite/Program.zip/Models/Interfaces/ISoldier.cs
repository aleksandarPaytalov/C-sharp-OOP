﻿namespace MilitaryElite.Models.Interfaces;

public interface ISoldier
{
    public int Id { get; }
    public string FirstName { get; }
    public string LastName { get; }
}