﻿namespace BirthdayCelebrations.Models.Interfaces
{
    public interface IIdentible
    {
       string Id { get; }
    }
}
