﻿namespace BorderControl.Models.Interfaces
{
    public interface IIdentible
    {
       string Id { get; }
    }
}
