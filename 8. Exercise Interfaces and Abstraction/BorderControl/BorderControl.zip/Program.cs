﻿using BorderControl.Core;

Engine engine = new Engine();
engine.Run();