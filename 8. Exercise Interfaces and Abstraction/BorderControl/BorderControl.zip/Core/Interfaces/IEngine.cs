﻿namespace BorderControl.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
