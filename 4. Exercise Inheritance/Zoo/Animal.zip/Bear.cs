﻿
namespace Zoo
{
    public class Bear : Mammal
    {
        public Bear(string name) : base(name)
        {
            Bear bear = new Bear("Blackstravnica");

        }
    }
}
